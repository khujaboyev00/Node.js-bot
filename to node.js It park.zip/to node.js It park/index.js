const TeleBot = require('telebot');

const bot = new TeleBot({
  token: '8073439815:AAFLHI66GQkwiehl3bnVEhVofiiziBvwJKQ',
  polling: { interval: 1000, retryTimeout: 5000 }
});

const keyboard = bot.keyboard([
  ['ℹ️ Loyiha haqida', '📌 Qanday ishlaydi?'],
  ['📍 Manzil', '📞 Aloqa'],
  ['📅 Tadbirlar', '📚 Kurslar'],
  ['🚀 Telegram', '📷 Instagram']
], { resize: true, once: false });

bot.on('/start', (msg) => {
  bot.sendMessage(msg.chat.id, 'Assalomu alaykum! "Muhammad al-Xorazmiy vorislari" botiga xush kelibsiz.', { markup: keyboard });
});

bot.on('text', (msg) => {
  const { text, chat } = msg;

  if (text === 'ℹ️ Loyiha haqida') {
    bot.sendMessage(chat.id, `📼 *"Muhammad al-Xorazmiy vorislari"* - yuqori sinf o‘quvchilarini raqamli texnologiyalar va xorijiy tillar bo‘yicha xalqaro sertifikat olish darajasidagi bilimlar bilan ta’minlash orqali IT mutaxassis sifatida tayyorlashni maqsad qilgan loyiha.

🗓 Loyiha O‘zbekiston Respublikasi Raqamli texnologiyalar vazirligi, Maktabgacha va maktab ta’limi vazirligi hamda Xorazm viloyati hokimligi bilan hamkorlikda amalga oshiriladi.`, { parseMode: 'Markdown' });
  } else if (text === '📌 Qanday ishlaydi?') {
    bot.sendMessage(chat.id, `🚩 6-10-sinf o‘quvchilari orasida IT va xorijiy tillarga qiziqishi va qobiliyati yuqori bo‘lgan yoshlar saralab olinadi.

🚩 O‘quvchilar darsdan tashqari maxsus guruhlarda o‘qitiladi.

🚩 Bitiruvchilar xalqaro sertifikat olish darajasida tayyorlanadi va xalqaro IT-bozoriga yo‘naltiriladi.`, { parseMode: 'Markdown' });
  } else if (text === '📍 Manzil') {
    bot.sendMessage(chat.id, '📍 "Muhammad al-Xorazmiy vorislari" loyihasi Xorazm viloyatida amalga oshirilmoqda.');
  } else if (text === '📞 Aloqa') {
    bot.sendMessage(chat.id, '📞 Bog‘lanish uchun: +998 71 209 11 11');
  } else if (text === '📅 Tadbirlar') {
    bot.sendMessage(chat.id, '📅 Loyiha doirasida bo‘lib o‘tadigan tadbirlar haqida ma’lumot olish uchun rasmiy kanallarimizga tashrif buyuring.');
  } else if (text === '📚 Kurslar') {
    bot.sendMessage(chat.id, '📚 IT va xorijiy tillar bo‘yicha kurslar loyihamiz doirasida tashkil etiladi.');
  } else if (text === '🚀 Telegram') {
    bot.sendMessage(chat.id, '🚀 Telegram kanalimizga qo‘shiling: [Muhammad al-Xorazmiy vorislari](https://t.me/al_xorazmiy_vorislari)', { parseMode: 'Markdown' });
  } else if (text === '📷 Instagram') {
    bot.sendMessage(chat.id, '📷 Instagram sahifamiz: [@al_xorazmiy_vorislari](https://instagram.com/al_xorazmiy_vorislari)', { parseMode: 'Markdown' });
  } else {
    bot.sendMessage(chat.id, 'Kechirasiz, tushunmadim. Iltimos, menyudagi tugmalardan foydalaning.');
  }
});

bot.start();
